# Customer Requirements Document (CRD)

> **Status:** Draft / Baseline Requirements
> **Project:** BaliKisah.com
> **Source URL:** https://balikisah.com/
> **Reference snapshot:** 5 Oktober 2026 (UTC+7)
> **Primary language:** Bahasa Indonesia
> **Product type:** Editorial / content publishing website about Bali and Indonesian culture, history, travel, culinary, traditions, and local stories.

## Basis of this document
Dokumen ini disusun berdasarkan observasi terhadap struktur dan konten BaliKisah.com yang tersedia publik pada saat penyusunan, ditambah interpretasi kebutuhan produk yang diperlukan agar situs dapat dikelola dan dikembangkan secara profesional. Detail yang tidak dapat diverifikasi dari permukaan publik ditandai sebagai **asumsi/target implementasi**, bukan klaim teknologi aktual.

## 1. Customer Profiles
### A. Reader / Explorer
Mencari informasi Bali untuk inspirasi, pengetahuan, atau rencana perjalanan.

### B. Culture Seeker
Mencari makna, sejarah, ritual, seni, dan konteks lokal.

### C. Travel Planner
Membutuhkan informasi praktis, itinerary, lokasi, estimasi aktivitas, dan tips.

### D. Content Team / Editor
Membutuhkan alat untuk menulis, mengelompokkan, mengoptimalkan, dan menerbitkan konten.

### E. Business / Partnership User
Membutuhkan media kit, kontak, sponsorship, dan inventory iklan.

## 2. Customer Jobs-to-be-Done
- “Saya ingin menemukan artikel yang menjawab pertanyaan saya tanpa harus membuka banyak situs.”
- “Saya ingin memahami budaya Bali tanpa bahasa yang terlalu akademis.”
- “Saya ingin menemukan ide perjalanan yang bisa langsung dipraktikkan.”
- “Saya ingin berpindah dari satu artikel ke topik terkait secara natural.”
- “Saya ingin situs yang nyaman dibaca di ponsel.”

## 3. Customer Requirements – Reader
| ID | Requirement | Priority |
|---|---|---|
| CR-R01 | Navigasi kategori mudah dipahami | Must |
| CR-R02 | Judul artikel jelas dan tidak terpotong | Must |
| CR-R03 | Gambar utama relevan dan tajam | Must |
| CR-R04 | Metadata penulis/tanggal/read time terlihat | Must |
| CR-R05 | Artikel mudah dibaca dengan tipografi nyaman | Must |
| CR-R06 | Related content tersedia | Should |
| CR-R07 | Search internal | Should |
| CR-R08 | Share artikel | Should |
| CR-R09 | Bookmark/favorite | Could |
| CR-R10 | Newsletter | Could |

## 4. Customer Requirements – Editor
- Draft, review, schedule, publish/unpublish.
- Category, tags, topic cluster, featured status.
- Featured image, alt text, caption, source/credit.
- SEO title, slug, meta description, canonical.
- Related article selection dan internal-link suggestions.
- Preview desktop/mobile.

## 5. Accessibility and Inclusion
- Kontras teks memadai.
- Keyboard accessible.
- Focus state jelas.
- Alt text untuk gambar informatif.
- Heading hierarchy semantik.
- Link tidak hanya bergantung pada warna.
- Bahasa yang mudah dipahami.

## 6. Customer Experience Principles
1. **Editorial first:** konten adalah pusat pengalaman.
2. **Calm browsing:** ruang putih cukup, tidak ramai.
3. **Trustworthy:** sumber, penulis, dan tanggal jelas.
4. **Discoverable:** artikel terkait selalu dekat.
5. **Fast:** visual menarik tidak boleh mengorbankan performa.

## 7. Acceptance Criteria High Level
Customer dapat membuka homepage, memilih kategori, membuka kartu artikel, membaca artikel, kembali ke kategori, dan menemukan artikel terkait tanpa kebingungan pada desktop maupun mobile.
