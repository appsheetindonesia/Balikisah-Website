# Market Requirements Document (MRD)

> **Status:** Draft / Baseline Requirements
> **Project:** BaliKisah.com
> **Source URL:** https://balikisah.com/
> **Reference snapshot:** 5 Oktober 2026 (UTC+7)
> **Primary language:** Bahasa Indonesia
> **Product type:** Editorial / content publishing website about Bali and Indonesian culture, history, travel, culinary, traditions, and local stories.

## Basis of this document
Dokumen ini disusun berdasarkan observasi terhadap struktur dan konten BaliKisah.com yang tersedia publik pada saat penyusunan, ditambah interpretasi kebutuhan produk yang diperlukan agar situs dapat dikelola dan dikembangkan secara profesional. Detail yang tidak dapat diverifikasi dari permukaan publik ditandai sebagai **asumsi/target implementasi**, bukan klaim teknologi aktual.

## 1. Executive Summary
BaliKisah.com diposisikan sebagai media digital yang membantu pembaca mengenal Bali secara lebih dekat melalui cerita, budaya, sejarah, wisata, kuliner, tradisi, kearifan lokal, dan panduan perjalanan. Situs publik saat ini menampilkan menu utama Home, Budaya, Tradisi, Kuliner, Sejarah, Wisata, Tips Traveling, dan Tentang Kami; footer juga menyediakan kebijakan privasi, syarat & ketentuan, kontak, disclaimer, FAQ, serta pengelompokan topik populer. 

Tujuan pasar utama adalah membangun **destination-content brand** yang dapat ditemukan melalui mesin pencari, dibaca dengan nyaman, dibagikan, dan dikembangkan menjadi aset media jangka panjang.

## 2. Market Problem
- Informasi tentang Bali tersebar di blog pribadi, media wisata, portal komersial, media sosial, dan situs perjalanan.
- Pembaca memerlukan sumber yang lebih terkurasi dan mudah dipindai sebelum mengambil keputusan perjalanan atau memahami konteks budaya.
- Konten budaya dan sejarah membutuhkan penyajian yang menarik tanpa menghilangkan konteks dan kehati-hatian terhadap klaim tradisi.
- Publisher membutuhkan struktur kategori dan topik yang dapat berkembang tanpa mengorbankan keterbacaan maupun SEO.

## 3. Market Opportunity
- Pertumbuhan pencarian intent informasional: destinasi, itinerary, kuliner khas, sejarah, tradisi, hidden gem, dan budaya.
- Long-tail SEO sangat luas karena setiap kota, tradisi, situs sejarah, kuliner, dan itinerary dapat menjadi kelompok topik sendiri.
- Konten evergreen dapat memiliki umur panjang dibanding konten berita harian.
- Situs dapat berkembang ke newsletter, sponsorship, affiliate, partnership pariwisata, dan konten multimedia setelah traffic organik stabil.

## 4. Target Audience
| Segmen | Kebutuhan | Konten prioritas |
|---|---|---|
| Wisatawan domestik | Inspirasi dan perencanaan | Wisata, itinerary, tips, kuliner |
| Wisatawan internasional | Konteks budaya & destinasi | Culture, history, practical guides |
| Penikmat budaya | Informasi mendalam | Tradisi, sejarah, filosofi, seni |
| Mahasiswa/pelajar | Referensi ringkas | Sejarah, tokoh, warisan budaya |
| Pembaca umum Indonesia | Storytelling | Cerita lokal, budaya, kuliner |
| Search-driven readers | Jawaban cepat | FAQ, how-to, listicle, glossary |

## 5. Market Positioning
**Positioning statement:** “BaliKisah.com adalah media digital yang menghubungkan pembaca dengan cerita, budaya, sejarah, wisata, kuliner, dan kehidupan Bali melalui konten yang mudah dipahami, menarik, dan bernilai konteks.”

Brand territory: **authentic – warm – cultural – editorial – approachable**.

## 6. Competitive Frame
Kompetisi berasal dari portal wisata besar, travel blog, media nasional, platform user-generated, social video, Google Discover/Search, dan creator economy. Keunggulan yang perlu dibangun bukan sekadar jumlah artikel, tetapi struktur informasi, konsistensi editorial, visual storytelling, dan topical authority.

## 7. Market Requirements
- Struktur kategori dan topik yang jelas.
- Halaman artikel yang cepat dan mudah dibaca.
- Search engine friendly: title, slug, meta description, canonical, schema, internal links.
- Content discovery: related articles, popular topics, read more, category archive, load more/pagination.
- Visual identity yang khas Bali tetapi tidak terasa seperti portal berita berat.
- Mobile-first dan accessible.
- Infrastruktur iklan yang tidak merusak reading experience.

## 8. Success Metrics
- Organic sessions dan organic users.
- Search impressions, CTR, keyword coverage, indexed pages.
- Engaged sessions, scroll depth, article completion proxy.
- Pages/session dan internal navigation rate.
- Returning readers.
- Ad viewability / revenue per session setelah monetisasi matang.
- Publish-to-index time dan content freshness.

## 9. Risks
- Konten terlalu generik/AI-like sehingga authority rendah.
- Klaim budaya yang tidak terverifikasi.
- Ketergantungan pada traffic search tanpa owned audience.
- Iklan berlebihan yang menurunkan UX.
- Duplikasi/topik kanibal antar artikel.

## 10. Strategic Direction
Prioritaskan topical clusters: **Budaya Bali → Tradisi → Sejarah → Wisata → Kuliner → Cerita Lokal → Panduan Perjalanan**, lalu dukung dengan landing pages topik populer dan internal linking yang kuat.
