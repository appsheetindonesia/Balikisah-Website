# Business Requirements Document (BRD)

> **Status:** Draft / Baseline Requirements
> **Project:** BaliKisah.com
> **Source URL:** https://balikisah.com/
> **Reference snapshot:** 5 Oktober 2026 (UTC+7)
> **Primary language:** Bahasa Indonesia
> **Product type:** Editorial / content publishing website about Bali and Indonesian culture, history, travel, culinary, traditions, and local stories.

## Basis of this document
Dokumen ini disusun berdasarkan observasi terhadap struktur dan konten BaliKisah.com yang tersedia publik pada saat penyusunan, ditambah interpretasi kebutuhan produk yang diperlukan agar situs dapat dikelola dan dikembangkan secara profesional. Detail yang tidak dapat diverifikasi dari permukaan publik ditandai sebagai **asumsi/target implementasi**, bukan klaim teknologi aktual.

## 1. Business Objective
Membangun dan mengembangkan BaliKisah.com sebagai properti media digital yang memiliki audience organik, topical authority, dan jalur monetisasi yang sehat.

## 2. Business Goals
- Meningkatkan organic visibility.
- Meningkatkan konsumsi multi-artikel per sesi.
- Memperkuat brand BaliKisah sebagai sumber cerita Bali.
- Membentuk library konten evergreen.
- Menyiapkan monetization-ready inventory.

## 3. Scope
### In Scope
Website editorial publik, kategori, artikel, author, topik, search, related content, SEO, analytics, ads, static pages, content management workflow.

### Out of Scope (fase awal)
Marketplace, booking engine, transaksi hotel, user-generated review marketplace, forum komunitas, social feed native.

## 4. Business Rules
- Setiap artikel wajib memiliki category utama.
- Setiap artikel wajib memiliki title, slug, excerpt, featured image, author, publish date, dan body.
- Artikel budaya/sejarah harus memiliki pemeriksaan editorial atas klaim faktual dan sensitivitas budaya.
- URL artikel harus stabil setelah publikasi; perubahan slug membutuhkan redirect.
- Konten terlarang, copy-paste tanpa atribusi, dan pelanggaran hak cipta tidak boleh dipublikasikan.

## 5. Revenue Model
Tahap 1: display ads.

Tahap 2: affiliate dan partnership.

Tahap 3: sponsored content, destination partnership, newsletter sponsorship, premium guides/digital products.

## 6. KPI Framework
| Area | KPI |
|---|---|
| Acquisition | Organic sessions, impressions, CTR |
| Engagement | Engaged session, scroll depth, pages/session |
| Retention | Returning users, repeat readers |
| Content | Articles published, index rate, topical coverage |
| Monetization | Ad RPM, revenue/session, affiliate CTR |
| Quality | Editorial correction rate, broken link rate |

## 7. Governance
Pemilik produk menetapkan tujuan dan prioritas. Editor menetapkan standar konten. Engineering menjaga reliability/performance/security. SEO/content strategist menjaga taxonomy dan search growth.

## 8. Business Acceptance
Sistem dianggap layak secara bisnis jika mampu menerbitkan konten secara terstruktur, menyediakan discovery yang kuat, memiliki analytics terpasang, SEO dasar terpenuhi, dan tidak mengorbankan kualitas UX untuk monetisasi.
