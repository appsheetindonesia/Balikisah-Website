# Technical Requirements Document (TRD)

> **Status:** Draft / Baseline Requirements
> **Project:** BaliKisah.com
> **Source URL:** https://balikisah.com/
> **Reference snapshot:** 5 Oktober 2026 (UTC+7)
> **Primary language:** Bahasa Indonesia
> **Product type:** Editorial / content publishing website about Bali and Indonesian culture, history, travel, culinary, traditions, and local stories.

## Basis of this document
Dokumen ini disusun berdasarkan observasi terhadap struktur dan konten BaliKisah.com yang tersedia publik pada saat penyusunan, ditambah interpretasi kebutuhan produk yang diperlukan agar situs dapat dikelola dan dikembangkan secara profesional. Detail yang tidak dapat diverifikasi dari permukaan publik ditandai sebagai **asumsi/target implementasi**, bukan klaim teknologi aktual.

## 1. Technical Objectives
Menyediakan arsitektur web editorial yang performant, secure, SEO-friendly, mudah dioperasikan, dan mudah berkembang.

## 2. Reference Architecture (Target / Recommended)
**Presentation:** server-rendered or statically generated HTML with progressive enhancement.

**Application/API:** modular backend exposing content, taxonomy, search, analytics hooks.

**Data:** relational DB preferred for editorial data; object storage/CDN for media.

**Cache:** page/data cache + CDN cache where appropriate.

**Search:** database full-text for MVP; dedicated search service only when traffic/content volume justifies it.

> Stack aktual situs tidak dapat dipastikan hanya dari public surface; bagian ini adalah arsitektur target.

## 3. Content Data Model
Entities: User/Author, Article, Category, Tag, Topic, Media, SEO, Redirect, Page, SiteSetting, AdSlot, AnalyticsEvent.

Relationships: Category 1:N Article; Author 1:N Article; Article N:M Tag; Article N:M Topic; Article 1:N Media.

## 4. URL Rules
- Lowercase slug.
- Hyphen-separated.
- Avoid dates in URL unless editorial policy needs them.
- Canonical self-referencing by default.
- 301 redirect on slug change.

## 5. SEO Technical Requirements
- XML sitemap.
- robots.txt.
- canonical.
- Open Graph/Twitter metadata.
- Article/Breadcrumb/Organization schema as applicable.
- Pagination/load-more must retain crawlable URLs or server-rendered fallback.

## 6. Performance
Targets:
- LCP < 2.5s on representative mobile.
- INP < 200ms.
- CLS < 0.1.
- HTML response should be cacheable where content is public.
- Images use responsive `srcset`, lazy loading below the fold, and fixed aspect-ratio containers.

## 7. Media Pipeline
Upload → validate type/size → strip unsafe metadata if required → create derivatives → store object → CDN → responsive delivery.
Preferred formats: AVIF/WebP with JPEG fallback where necessary.

## 8. Security
- HTTPS only.
- Secure cookies.
- CSRF protection for authenticated mutations.
- XSS-safe rich text rendering.
- Rate limiting for forms/search.
- Admin MFA recommended.
- Least-privilege roles.
- Dependency and OS patching.

## 9. Observability
Logs: request errors, publish errors, auth failures.
Metrics: latency, 5xx, cache hit ratio, DB load, media failures.
Alerts: 5xx spike, uptime failure, certificate expiry, backup failure.

## 10. Deployment
Environments: local/dev, staging, production.
CI/CD: lint → unit test → integration → build → security checks → deploy → smoke test.

## 11. Backup & Disaster Recovery
- Automated daily DB backup minimum target.
- Media replication/versioning.
- Restore test scheduled periodically.
- Define RPO/RTO based on business criticality; recommended initial target RPO ≤24h, RTO ≤4h.

## 12. Third-Party Dependencies
Analytics, ad network, email service, CDN, captcha/anti-abuse, search provider as needed. Every third party must be reviewed for performance, privacy, and fallback behavior.

## 13. Technical Acceptance
Production release passes: build, security, responsive, browser, SEO crawl, performance, accessibility smoke tests, backup verification, and rollback test.
