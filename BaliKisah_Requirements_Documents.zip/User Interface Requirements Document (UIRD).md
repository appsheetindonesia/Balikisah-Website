# User Interface Requirements Document (UIRD)

> **Status:** Draft / Baseline Requirements
> **Project:** BaliKisah.com
> **Source URL:** https://balikisah.com/
> **Reference snapshot:** 5 Oktober 2026 (UTC+7)
> **Primary language:** Bahasa Indonesia
> **Product type:** Editorial / content publishing website about Bali and Indonesian culture, history, travel, culinary, traditions, and local stories.

## Basis of this document
Dokumen ini disusun berdasarkan observasi terhadap struktur dan konten BaliKisah.com yang tersedia publik pada saat penyusunan, ditambah interpretasi kebutuhan produk yang diperlukan agar situs dapat dikelola dan dikembangkan secara profesional. Detail yang tidak dapat diverifikasi dari permukaan publik ditandai sebagai **asumsi/target implementasi**, bukan klaim teknologi aktual.

## 1. Design Mandate
**Tema visual UIRD wajib mengikuti foto referensi terlampir secara identik pada level art direction:** editorial Bali klasik, warm ivory paper, serif display typography, muted sepia imagery, terracotta-brown accent, thin warm-gray dividers, rounded category chips, card grid yang rapat dan tenang, serta header minimalis.

> **Reference image:** screenshot kategori “Sejarah dan Babad Bali” yang diberikan user pada percakapan ini.

## 2. Visual DNA – Locked Tokens
| Token | Target |
|---|---|
| Page background | Warm ivory/cream, kira-kira `#F5EEDD` – jangan gunakan putih dingin sebagai background utama |
| Header background | Near-white warm `#FFFDFC` |
| Primary text | Deep brown `#35261F` |
| Muted text | Warm gray-brown `#6C6259` |
| Accent | Terracotta/copper brown `#A9653B` |
| Accent hover | Darker terracotta `#8E4F2E` |
| Chip background | Pale sand `#E9D8C5` |
| Card border | Warm beige `#E2D4C2` |
| Card surface | Soft cream `#FFFDF8` |
| Shadow | Very soft, low-opacity warm shadow |

**Catatan:** Nilai hex di atas adalah target design-token untuk rekonstruksi. Foto merupakan sumber visual utama; final sampling dari screenshot dapat menyesuaikan ±5–8% tanpa mengubah karakter.

## 3. Typography
### Display / Brand / H1
Gunakan serif klasik dengan karakter editorial. Preferred stack: `Georgia, 'Times New Roman', serif` atau webfont serif setara yang bentuknya mendekati referensi.

### UI / Body
Gunakan sans-serif netral: `Inter, Arial, Helvetica, sans-serif`.

### Hierarchy
- Logo: serif, bold/semibold, dark brown.
- Page eyebrow: sans, uppercase/lowercase kecil, muted brown.
- H1 kategori: serif, bold, dark brown.
- Card title: serif, semibold.
- Excerpt/meta: sans, small, muted.

## 4. Header – Pixel Intent
- Header horizontal, tinggi ringkas.
- Konten berada pada centered max-width.
- Logo `balikisah.com` berada di kiri.
- Navigation berada di kanan: **Kategori**, **Kenajaan** [pertahankan label referensi jika memang ingin identik], **Stonian**, **Blog**, **Contact**, lalu CTA.
- CTA “Contact us” berbentuk pill, background terracotta, teks putih/cream.
- Header memiliki bottom border/divider tipis.
- Tidak memakai gradient, glassmorphism, neon, atau shadow berat.

## 5. Category Archive Header
Urutan visual wajib:
1. breadcrumb/eyebrow kecil “Kategori archive”;
2. H1 besar “Sejarah dan Babad Bali”;
3. row category filters/chips;
4. card grid.

H1 harus dominan tetapi tidak memenuhi viewport; negative space di atas dan bawah harus terasa seperti referensi.

## 6. Category Chips
- Bentuk pill dengan radius tinggi.
- Warna muted sand.
- Chip aktif menggunakan terracotta/copper.
- Text small, compact.
- Gap antar chip konsisten dan rapat.
- Tidak memakai outline biru default browser.

Contoh referensi: `Kerajaan Bali`, `Candi`, `Tokoh Sejarah`, `Soratirin`, `Kerajaan`, `Histiowia`.

## 7. Article Card Grid
### Desktop reference behavior
- 4 kolom pada area konten utama.
- Gap horizontal/vertical kecil dan konsisten.
- Card adalah rectangle dengan rounded corners kecil–sedang.
- Image memenuhi lebar card dan memiliki crop konsisten.
- Body card putih/cream dengan padding compact.

### Card Anatomy
1. Featured image.
2. Category/meta kecil (opsional bila dibutuhkan).
3. Title 2–3 baris.
4. Excerpt 2–4 baris.
5. Date/reading metadata.

### Image treatment
Untuk tampilan historical/heritage pada archive referensi, gambar diberi treatment sepia/archival, tetapi foto pada artikel modern boleh tetap natural jika konten memerlukannya. Filter target kira-kira `grayscale(0.25) sepia(0.45) saturate(0.60) contrast(0.92)`.

## 8. Spacing System
Gunakan base 4/8 px.
- Page gutters desktop: 32–64 px.
- Content max width: 1120–1200 px.
- Section top spacing: 40–64 px.
- H1 bottom spacing: 18–24 px.
- Chip row bottom: 24–32 px.
- Card gap: 12–20 px.
- Card inner padding: 14–16 px.

## 9. Border Radius
- Card: 8–12 px.
- CTA: 999 px.
- Chip: 999 px.
- Image: mengikuti card radius tanpa hard border tebal.

## 10. States
Hover: sedikit darken pada text/accent; card boleh naik 1–2 px dengan shadow sangat tipis.

Focus: visible 2 px outline menggunakan turunan warna accent dengan kontras yang cukup.

Active chip: accent fill + light text.

Disabled: muted, tidak hilang dari DOM.

## 11. Responsive Behavior
- Desktop ≥1200 px: 4-column archive.
- Tablet 768–1199 px: 2–3 columns tergantung lebar.
- Mobile <768 px: 1 column; header navigation berubah menjadi menu compact.
- H1 mengecil tetapi tetap serif dan dominan.
- Chips dapat horizontal-scroll tanpa wrapping berantakan.

## 12. Accessibility Visual
- Minimum body text 16 px pada mobile.
- Tap targets minimum 44×44 px.
- Jangan menjadikan warna sebagai satu-satunya penanda aktif.
- Semua gambar informatif memiliki alt.
- Focus state terlihat.

## 13. Component Inventory
Header, Logo, DesktopNav, MobileNav, PrimaryCTA, Breadcrumb, ArchiveHeader, CategoryChip, ChipGroup, ArticleCard, ArticleGrid, ArticleMeta, Pagination/LoadMore, Footer, FooterLinkGroup, SearchInput, RelatedArticleCard, AdSlot, NewsletterForm, ContactForm.

## 14. Page-Level UI Requirements
### Homepage
Hero/featured content → latest stories → topic clusters → hottest articles → read more → footer.

### Category Archive
Archive eyebrow → H1 → chips/filter → grid → load more/pagination → footer.

### Article Detail
Breadcrumb/category → H1 → metadata → hero image → article body → related articles → footer.

### Static pages
Clean editorial template dengan H1 serif, readable content width, dan section spacing yang sama.

## 15. Do / Don’t
**Do:** warm ivory, serif headings, terracotta CTA, sepia archival photos, compact cards, calm whitespace.

**Don’t:** pure black, stark blue links, purple gradients, glass cards, heavy shadows, oversized dashboard-style widgets, excessive rounded containers.

## 16. 100% Reference-Matching Checklist
- [ ] Header proportions mengikuti screenshot.
- [ ] Logo serif dan posisi kiri.
- [ ] Menu compact di kanan.
- [ ] CTA terracotta pill.
- [ ] Background warm ivory.
- [ ] H1 serif dark-brown.
- [ ] Chips pill dengan active terracotta.
- [ ] 4-column card grid desktop.
- [ ] Gambar archival/sepia pada archive history.
- [ ] Card surface warm-white/cream.
- [ ] Border dan divider tipis warm-gray.
- [ ] Spacing dan negative space tidak agresif.
- [ ] Tidak menambahkan elemen visual yang tidak ada pada referensi kecuali diperlukan oleh fungsi.

## 17. Reference Screenshot Geometry
Untuk rekonstruksi komposisi dari screenshot 756×425 px:
- top header kira-kira 43 px,
- main content mulai sekitar 60 px dari top,
- content left/right margin sekitar 80 px pada frame screenshot,
- H1 sekitar 31–34 px,
- chip tinggi sekitar 22–26 px,
- card row 4 kolom,
- image area sekitar 85–95 px pada frame screenshot,
- card corner 8–10 px.

Angka ini dipakai untuk menjaga **proposi**; implementasi production harus mengubah ukuran secara responsif, bukan menyalin pixel screenshot secara fixed.
